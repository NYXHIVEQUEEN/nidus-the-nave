# NIDUS — standalone pass (boot + QoL)

This folder is a playable hive with the suggested task list shipped.

Open `index.html` via a local server (not file://) so audio/sky fetch.

Save keys stay `nidus.save.v1` + `.bak` + `nidus.slot.0..2` + `nidus.prefs.v1`.
